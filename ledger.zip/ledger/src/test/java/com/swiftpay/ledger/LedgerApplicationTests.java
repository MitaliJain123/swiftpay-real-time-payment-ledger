package com.swiftpay.ledger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LedgerApplicationTests {

	@Test
	void contextLoads() {
	}

}
